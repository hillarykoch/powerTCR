# This function does model fitting and threshold selection as described in Desponds et al (2016)
# Details on page 5 of supplement (right column)
# x is a vector of clone sizes

despondsize <- function(x){
    x <- sort(x)
    Cmins <- unique(x)
    alpha <- rep(NA, length(Cmins))
    KS <- rep(NA, length(Cmins))

    # n is the number of points greater than each unique clone size
    n <- rep(NA, length(Cmins))
    for(i in 1:length(Cmins)){
        # Grab all data greater than threshhold
        d <- x[x > Cmins[i]]

        # Compute power law exponent
        n[i] <- length(d)
        alpha[i] <- n[i]*(sum(log(d/Cmins[i])))^(-1) + 1

        ##
        ## Compute KS distance at each threshhold
        ##

        # Compute empirical cdf
        empir.cdf <- rep(NA, length(d))
        for(j in 1:length(d)){
            empir.cdf[j] <- mean(d <= d[j])
        }

        # Compute estimated cdf from observed data
        est.cdf <- VGAM::ppareto(d, scale=Cmins[i], shape = alpha[i]-1)

        KS[i] <- max(abs(est.cdf - empir.cdf))
    }

    min.KS <- min(KS, na.rm = T)
    Cmin <- Cmins[KS == min(KS, na.rm = T)][1]
    powerlaw.exponent <- alpha[KS == min(KS, na.rm = T)]
    powerlaw.exponent <- powerlaw.exponent[!is.na(powerlaw.exponent)]
    out <- c(min.KS, Cmin, powerlaw.exponent, powerlaw.exponent-1)
    names(out) <- c("min.KS", "Cmin", "powerlaw.exponent", "pareto.alpha")
    out
}
